insert into creditscore(pancard,customer_name,creditscore)
	values('ABCD1234','ARJUN',722);
insert into creditscore(pancard,customer_name,creditscore)
	values('MNQR45678','JAMES',522);
insert into creditscore(pancard,customer_name,creditscore)
	values('BLUPK1224','ABCDE',705);
insert into creditscore(pancard,customer_name,creditscore)
	values('BLUP4455','GEMINI',600);

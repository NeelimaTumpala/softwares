package credit.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import credit.entity.CreditScore;

@Repository
public interface CreditScoreDao extends JpaRepository<CreditScore, String>{
	@Query("select creditscore from CreditScore cr where cr.pancard=?1")
	Optional<Double> getCreditScoreByPanCard(String pancard);
}

package credit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditScoreMain {
	public static void main(String[] args) {
		SpringApplication.run(CreditScoreMain.class, args);
	}
}

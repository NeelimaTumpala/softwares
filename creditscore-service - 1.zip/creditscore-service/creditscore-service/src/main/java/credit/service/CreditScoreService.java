package credit.service;

import java.util.List;
import java.util.Optional;

import credit.entity.CreditScore;

public interface CreditScoreService {
	public List<CreditScore> getAllDetails();
	public Optional<Double> getCreditScoreByPancard(String pancard);
}

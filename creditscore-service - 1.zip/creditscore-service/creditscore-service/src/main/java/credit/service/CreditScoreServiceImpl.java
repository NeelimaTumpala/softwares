package credit.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import credit.dao.CreditScoreDao;
import credit.entity.CreditScore;

@Service
public class CreditScoreServiceImpl implements CreditScoreService{
	@Autowired
	CreditScoreDao dao;
	
	@Override
	public List<CreditScore> getAllDetails() {
		return dao.findAll();
	}

	@Override
	public Optional<Double> getCreditScoreByPancard(String pancard) {
		Optional<Double> score = dao.getCreditScoreByPanCard(pancard);
		return score;
		
	}

}

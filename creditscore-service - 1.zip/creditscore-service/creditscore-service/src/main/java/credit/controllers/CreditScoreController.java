package credit.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import credit.entity.CreditScore;
import credit.service.CreditScoreService;

@RestController
@RequestMapping("/creditscore")
public class CreditScoreController {
	@Autowired
	CreditScoreService service;
	
	@GetMapping
	public ResponseEntity<List<CreditScore>> getAllDetails() {
		return new ResponseEntity<List<CreditScore>>(service.getAllDetails(),HttpStatus.OK);
	}
	
	@GetMapping("/{pancard}")  
	public ResponseEntity<Optional<Double>> getCreditScoreByPancard(@PathVariable String pancard){
		Optional<Double> score = service.getCreditScoreByPancard(pancard);
		return new ResponseEntity<Optional<Double>>(score,HttpStatus.OK);
			
	}
}

package loan.dao;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "creditscore-service", url = "localhost:2023")
public interface CreditScoreProxy {
	@GetMapping("/creditscore/{pancard}")  
	public Optional<Double> getCreditScoreByPancard(@PathVariable String pancard);	
}

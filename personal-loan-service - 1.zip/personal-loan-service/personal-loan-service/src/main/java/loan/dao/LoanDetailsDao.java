package loan.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import loan.entity.LoanDetails;

@Repository
public interface LoanDetailsDao extends JpaRepository<LoanDetails, Integer>{
	@Query("select ld from LoanDetails ld where ld.loanId=?1")
	LoanDetails getLoanDetailsById(int id);
}

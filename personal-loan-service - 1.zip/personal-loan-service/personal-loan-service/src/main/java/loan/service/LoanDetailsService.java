package loan.service;

import java.util.List;
import loan.entity.LoanDetails;

public interface LoanDetailsService {
	void addLoanDetails(LoanDetails loanDetails);
	String verifyLoan(int loanid);
	LoanDetails getLoanDetailsById(int loanid);
	List<LoanDetails> getAllLoansDetails();
}

package loan.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import loan.dao.CreditScoreProxy;
import loan.dao.LoanDetailsDao;
import loan.entity.LoanDetails;

@Service
public class LoanDetailsServiceImpl implements LoanDetailsService{

	@Autowired
	LoanDetailsDao dao;
	
	@Autowired
	CreditScoreProxy proxy;
	
	@Override
	public void addLoanDetails(LoanDetails loanDetails) {
		dao.save(loanDetails);		
	}

	@Override
	public String verifyLoan(int loanid) {
		LoanDetails loanDetails = dao.getLoanDetailsById(loanid);
		//Call getCreditScoreByPanCard from creditscore-service
		Optional<Double> creditscore = proxy.getCreditScoreByPancard(loanDetails.getPancard());
		double score = creditscore.get();
		loanDetails.setCreditScore(score);
		if(score>=700) {
			loanDetails.setStatus("Approved");
		}
		else {
			loanDetails.setStatus("Rejected");
			loanDetails.setComments("Reason: credit score < 700"); 
		}
		dao.save(loanDetails);
		return "status updated";
		
	}

	@Override
	public LoanDetails getLoanDetailsById(int loanid) {
		
		return dao.getLoanDetailsById(loanid);
	}

	@Override
	public List<LoanDetails> getAllLoansDetails() {
		return dao.findAll();
	}

}

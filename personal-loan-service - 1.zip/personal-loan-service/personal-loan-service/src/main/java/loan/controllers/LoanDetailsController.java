package loan.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import loan.entity.LoanDetails;
import loan.service.LoanDetailsService;

@RestController
@RequestMapping("/loandetails")
public class LoanDetailsController {
	@Autowired
	LoanDetailsService service;
	
	@PostMapping
	public ResponseEntity<String> addLoanDetails(@RequestBody LoanDetails loanDetails) {
		service.addLoanDetails(loanDetails);
		return new ResponseEntity<String>("added..",HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<LoanDetails>> getAllLoansDetails() {
		
		return new ResponseEntity<List<LoanDetails>>(service.getAllLoansDetails(),HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<LoanDetails> getLoanDetailsById(@PathVariable int id) {
		LoanDetails loanDetails = service.getLoanDetailsById(id);
		return new ResponseEntity<LoanDetails>(loanDetails,HttpStatus.OK);
	}
	
	@GetMapping("/verify/{loanid}")
	public ResponseEntity<String> verifyLoanDetails(@PathVariable int loanid) {
		String str = service.verifyLoan(loanid);
		return new ResponseEntity<String>(str,HttpStatus.OK);
	}
		
}
